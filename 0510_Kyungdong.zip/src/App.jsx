import Index from './components/Index';

const App = () => {
    return (
        <div>
            <Index />
        </div>
    );
};

export default App;
