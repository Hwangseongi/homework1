export default [
    {
        id: 1,
        imgurl: 'http://www.kyungdong.co.kr/ko/front/image/main/main_foot_icn01.png',
        kor: 'CEO 인사말',
        eng: 'CEO’s Greetings',
    },
    {
        id: 2,
        imgurl: 'http://www.kyungdong.co.kr/ko/front/image/main/main_foot_icn01.png',
        kor: '경영이념',
        eng: 'Management Philosophy',
    },
    {
        id: 3,
        imgurl: 'http://www.kyungdong.co.kr/ko/front/image/main/main_foot_icn01.png',
        kor: '관계사',
        eng: 'Business Overview',
    },
];
