export default [
    {
        id: 1,
        imgurl: 'http://www.kyungdong.co.kr/upload_dir/board/8066666455d70cc8975a7f.jpg',
        title: '하천정화',
    },
    {
        id: 2,
        imgurl: 'http://www.kyungdong.co.kr/upload_dir/board/9258442415d155b6f81a24.jpg',
        title: '도로정화활동',
    },
    {
        id: 3,
        imgurl: 'http://www.kyungdong.co.kr/upload_dir/board/8684783645d145297bc7ac.jpg',
        title: '쌀나눔봉사',
    },
    {
        id: 4,
        imgurl: 'http://www.kyungdong.co.kr/upload_dir/board/4398543445d15553c80a54.jpeg',
        title: '연탄나눔봉사',
    },
];
