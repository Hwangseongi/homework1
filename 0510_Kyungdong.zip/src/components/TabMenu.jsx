const TabMenu = () => {
    return (
        <>
            <li className="on">
                <a href="#">MAIN</a>
            </li>
            <li>
                <a href="#">BUSINESS</a>
            </li>
            <li>
                <a href="#">TECHNOLOGY</a>
            </li>
            <li>
                <a href="#">PUBLIC RELATIONS</a>
            </li>
            <li>
                <a href="#">ABOUT</a>
            </li>
        </>
    );
};

export default TabMenu;
